# Sougata_label_71412 > 2024-07-22 7:20am
https://universe.roboflow.com/ohrclabel/sougata_label_71412

Provided by a Roboflow user
License: CC BY 4.0

